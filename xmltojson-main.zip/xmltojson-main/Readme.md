Install Nodejs
check your node version using node --version

input.xml, input1.xml, and test_input xml are the input files for this program

output.json is a output file for this program

To run the application
in app.js, line no 111 you can change the input file name
in line 118, you can give the output file name.